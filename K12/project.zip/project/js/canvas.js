// js/canvas.js - KHÔNG DÙNG IMPORT/EXPORT
window.CanvasManager = class {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.isDrawing = false;
        this.isDrawMode = false;
        this.history = [];
        this.currentTool = 'pen';
        this.startX = 0;
        this.startY = 0;
        this.lastX = 0;
        this.lastY = 0;
        this.imageBeforeShape = null;
    }

    initialize() {
        this.canvas = document.getElementById('drawCanvas');
        if (!this.canvas) {
            console.error('Canvas element not found');
            return;
        }
        
        this.ctx = this.canvas.getContext('2d');
        this.setupCanvas();
        this.setupEventListeners();
        this.setupToolbar();
    }

    setupCanvas() {
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
        
        this.ctx.lineJoin = 'round';
        this.ctx.lineCap = 'round';
    }

    resizeCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }

    setupEventListeners() {
        // Mouse events
        this.canvas.addEventListener('mousedown', (e) => this.startDraw(e));
        this.canvas.addEventListener('mousemove', (e) => this.drawMove(e));
        this.canvas.addEventListener('mouseup', () => this.endDraw());
        this.canvas.addEventListener('mouseleave', () => this.endDraw());

        // Touch events
        this.canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            this.startDraw(e.touches[0]);
        }, { passive: false });
        
        this.canvas.addEventListener('touchmove', (e) => {
            e.preventDefault();
            this.drawMove(e.touches[0]);
        }, { passive: false });
        
        this.canvas.addEventListener('touchend', () => this.endDraw());
    }

    setupToolbar() {
        const toggleBtn = document.getElementById('toggleMenu');
        const exitBtn = document.getElementById('exitBtn');
        const clearBtn = document.getElementById('clearBtn');
        const undoBtn = document.getElementById('undoBtn');
        const saveBtn = document.getElementById('saveBtn');
        const toolSelect = document.getElementById('tool');

        if (toggleBtn) toggleBtn.addEventListener('click', () => this.toggleDrawMode());
        if (exitBtn) exitBtn.addEventListener('click', () => this.toggleDrawMode());
        if (clearBtn) clearBtn.addEventListener('click', () => this.clearCanvas());
        if (undoBtn) undoBtn.addEventListener('click', () => this.undo());
        if (saveBtn) saveBtn.addEventListener('click', () => this.saveCanvas());
        if (toolSelect) toolSelect.addEventListener('change', (e) => {
            this.currentTool = e.target.value;
        });
    }

    toggleDrawMode() {
        this.isDrawMode = !this.isDrawMode;
        const toolbar = document.getElementById('drawToolbar');
        
        this.canvas.style.display = this.isDrawMode ? 'block' : 'none';
        if (toolbar) toolbar.style.display = this.isDrawMode ? 'flex' : 'none';
        this.canvas.style.pointerEvents = this.isDrawMode ? 'auto' : 'none';
    }

    getPosition(e) {
        const rect = this.canvas.getBoundingClientRect();
        return {
            x: (e.clientX - rect.left) * (this.canvas.width / rect.width),
            y: (e.clientY - rect.top) * (this.canvas.height / rect.height)
        };
    }

    startDraw(e) {
        if (!this.isDrawMode) return;

        this.history.push(this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height));
        this.isDrawing = true;
        
        const pos = this.getPosition(e);
        this.startX = this.lastX = pos.x;
        this.startY = this.lastY = pos.y;

        if (this.currentTool !== 'pen') {
            this.imageBeforeShape = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        }

        this.ctx.beginPath();
    }

    drawMove(e) {
        if (!this.isDrawing || !this.isDrawMode) return;

        const colorPicker = document.getElementById('colorPicker');
        const drawWidth = document.getElementById('draw-width');
        
        this.ctx.strokeStyle = colorPicker ? colorPicker.value : '#6b21a8';
        this.ctx.lineWidth = drawWidth ? drawWidth.value : 2;

        if (this.currentTool !== 'pen' && this.imageBeforeShape) {
            this.ctx.putImageData(this.imageBeforeShape, 0, 0);
        }

        const pos = this.getPosition(e);
        
        this.ctx.beginPath();
        switch (this.currentTool) {
            case "pen":
                this.drawPen(pos);
                break;
            case "line":
                this.drawLine(pos);
                break;
            case "dashedLine":
                this.drawDashedLine(pos);
                break;
            case "rect":
                this.drawRect(pos);
                break;
            case "circle":
                this.drawCircle(pos);
                break;
            case "ellipse":
                this.drawEllipse(pos);
                break;
            case "parallelogram":
                this.drawParallelogram(pos);
                break;
            case "box":
                this.drawBox(pos);
                break;
            case "pyramid3":
                this.drawPyramid3(pos);
                break;
            case "pyramid4":
                this.drawPyramid4(pos);
                break;
            case "sphere":
                this.drawSphere(pos);
                break;
        }
        this.ctx.stroke();
    }

    endDraw() {
        if (this.isDrawing) {
            this.isDrawing = false;
            this.ctx.beginPath();
        }
    }

    // Drawing Tools
    drawPen(pos) {
        this.ctx.moveTo(this.lastX, this.lastY);
        this.ctx.lineTo(pos.x, pos.y);
        [this.lastX, this.lastY] = [pos.x, pos.y];
    }

    drawLine(pos) {
        this.ctx.moveTo(this.startX, this.startY);
        this.ctx.lineTo(pos.x, pos.y);
    }

    drawDashedLine(pos) {
        this.ctx.setLineDash([8, 6]);
        this.ctx.moveTo(this.startX, this.startY);
        this.ctx.lineTo(pos.x, pos.y);
        this.ctx.setLineDash([]);
    }

    drawRect(pos) {
        this.ctx.strokeRect(this.startX, this.startY, pos.x - this.startX, pos.y - this.startY);
    }

    drawCircle(pos) {
        const radius = Math.hypot(pos.x - this.startX, pos.y - this.startY);
        this.ctx.arc(this.startX, this.startY, radius, 0, Math.PI * 2);
    }

    drawEllipse(pos) {
        const radiusX = Math.abs(pos.x - this.startX);
        const radiusY = Math.abs(pos.y - this.startY);
        this.ctx.ellipse(this.startX, this.startY, radiusX, radiusY, 0, 0, Math.PI * 2);
    }

    drawParallelogram(pos) {
        const width = pos.x - this.startX;
        const height = pos.y - this.startY;
        const offset = width * 0.3;
        
        this.ctx.moveTo(this.startX + offset, this.startY);
        this.ctx.lineTo(this.startX + width + offset, this.startY);
        this.ctx.lineTo(this.startX + width - offset, this.startY + height);
        this.ctx.lineTo(this.startX - offset, this.startY + height);
        this.ctx.closePath();
    }

    drawBox(pos) {
        const width = pos.x - this.startX;
        const height = pos.y - this.startY;
        const depth = Math.min(Math.abs(width), Math.abs(height)) * 0.4;
        
        // Front face
        this.ctx.strokeRect(this.startX, this.startY, width, height);
        // Back face
        this.ctx.strokeRect(this.startX + depth, this.startY - depth, width, height);
        // Connecting lines
        [
            [this.startX, this.startY, this.startX + depth, this.startY - depth],
            [this.startX + width, this.startY, this.startX + width + depth, this.startY - depth],
            [this.startX, this.startY + height, this.startX + depth, this.startY + height - depth],
            [this.startX + width, this.startY + height, this.startX + width + depth, this.startY + height - depth]
        ].forEach(([x1, y1, x2, y2]) => {
            this.ctx.moveTo(x1, y1);
            this.ctx.lineTo(x2, y2);
        });
    }

    drawPyramid3(pos) {
        const baseLeft = { x: this.startX, y: pos.y };
        const baseRight = { x: pos.x, y: pos.y };
        const apex = { x: (this.startX + pos.x) / 2, y: this.startY };
        
        this.ctx.moveTo(apex.x, apex.y);
        this.ctx.lineTo(baseLeft.x, baseLeft.y);
        this.ctx.lineTo(baseRight.x, baseRight.y);
        this.ctx.closePath();
    }

    drawPyramid4(pos) {
        const width = pos.x - this.startX;
        const height = pos.y - this.startY;
        const apex = { x: this.startX + width / 2, y: this.startY - height };
        
        // Base
        this.ctx.strokeRect(this.startX, this.startY, width, height);
        // Edges
        [
            [this.startX, this.startY],
            [this.startX + width, this.startY],
            [this.startX, this.startY + height],
            [this.startX + width, this.startY + height]
        ].forEach(([bx, by]) => {
            this.ctx.moveTo(apex.x, apex.y);
            this.ctx.lineTo(bx, by);
        });
    }

    drawSphere(pos) {
        const radius = Math.abs(pos.x - this.startX);
        
        // Main circle
        this.ctx.arc(this.startX, this.startY, radius, 0, Math.PI * 2);
        
        // Cross section
        this.ctx.beginPath();
        this.ctx.setLineDash([6, 4]);
        this.ctx.ellipse(this.startX, this.startY, radius, radius / 2.5, 0, 0, Math.PI * 2);
        this.ctx.setLineDash([]);
    }

    // Canvas Operations
    clearCanvas() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.history = [];
    }

    undo() {
        if (this.history.length > 0) {
            this.ctx.putImageData(this.history.pop(), 0, 0);
        }
    }

    saveCanvas() {
        const link = document.createElement('a');
        link.download = 'ban_ve.png';
        link.href = this.canvas.toDataURL();
        link.click();
    }
};

// Tạo global instance và initialize
window.canvasManager = new CanvasManager();

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.canvasManager.initialize();
});